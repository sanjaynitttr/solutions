import os

for root, dir1, filenames in os.walk('/home/malwarelab/dataset/Linux_malware/'):
	for filename in filenames:
		print filename
		os.system('echo "trojan" | sudo -S python limon.py '+ root+filename +' -t 30 -x')


